<script setup>
import Nav from './components/HelloWorld.vue'
</script>

<template>
  <v-app>
    <Nav />

  </v-app>
</template>


